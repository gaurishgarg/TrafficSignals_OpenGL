------------------------------CONTROLS-------------------------------------------
--------------------------------------------------------------------------------

Home: Go to Play Area (One you enter play area you cannot go back to main menu)

UP ARROW: Move car forward
DOWN ARROW: Move car backward
LEFT ARROW: Move car left
RIGHT ARROW: Move car right

------------------------------LAUNCHING THE GAME-------------------------------------------
-------------------------------------------------------------------------------------------

Just click on the play button


-----------------------------TERMS OF SERVICE------------------------------------------
---------------------------------------------------------------------------------------
This was developed as a lab project assignment for Computer Graphics using OpenGL/C++

This project is 100% original and no part of it is plagiarised.

Developed by Gaurish Garg and (Rishabh Malhotra)

For Educational Use only

(c) All rights reserved

No part of this project including the code (except the DLL-files) may be reproduced, stored in a retrieval system or transmitted in any form or by any means, electronic, mechanical, photocopying, recording or otherwise, without permission, else a strict legal action will be taken against the defaulters.

All the supporting DLL files were downloaded from https://www.dll-files.com/

